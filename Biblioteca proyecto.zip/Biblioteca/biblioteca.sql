-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 11-04-2025 a las 14:08:32
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `biblioteca`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `published_year` int(11) NOT NULL CHECK (`published_year` <= 2025),
  `isbn` varchar(13) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `books`
--

INSERT INTO `books` (`id`, `title`, `author`, `published_year`, `isbn`, `description`, `created_at`, `updated_at`) VALUES
(1, '1984', 'George', 1984, '978-04-06-406', 'Historia distopica', '2025-04-10 20:10:22', '2025-04-11 00:52:23'),
(2, 'cien años de soledad ', 'Gabriel Garcia Marquez', 1967, '978-843760681', 'Saga familiar que narra la vida de los buendia en el pueblo ficticio de macondo explorando temas de soledad, amor y destino.', '2025-04-10 23:19:34', '2025-04-10 23:19:34'),
(3, 'El principito', 'Antonie de Saint-Exupéry', 1943, '978-843761065', 'Un cuento poetico y filosofico sobre un joven principe que explora distintos planetas y aprende las verdades de la vida y el amor.', '2025-04-10 23:19:34', '2025-04-10 23:19:34'),
(8, 'El origen de las especies', 'Charles Darwin', 1859, '978-0-553-213', ' Introduce la teoría de la evolución por selección natural.', '2025-04-11 00:56:18', '2025-04-11 00:56:18'),
(9, 'Crónica de una muerte anunciada', 'Gabriel García Márquez', 1981, '978-0-307-389', 'Novela basada en un asesinato anunciado', '2025-04-11 00:57:19', '2025-04-11 00:57:19'),
(10, 'La teoría del todo', 'Stephen Hawking', 2002, '978-0-553-802', 'Explicación accesible del universo según Hawking.', '2025-04-11 00:58:08', '2025-04-11 00:58:08'),
(11, 'El corredor del laberinto', 'James Dashner', 2009, '978-0-385-735', ' Un grupo de adolescentes atrapados en un laberinto buscan escapar mientras enfrentan desafíos y secretos oscuros', '2025-04-11 00:59:20', '2025-04-11 00:59:20'),
(12, 'Los juegos del hambre', 'Suzanne Collins', 2008, '978-0-439-023', ' En una sociedad totalitaria, Katniss Everdeen lucha por sobrevivir en unos juegos mortales transmitidos para el entretenimiento del Capitolio.', '2025-04-11 01:00:02', '2025-04-11 01:00:02'),
(13, 'El fin de los sueños', 'Carlos García Miranda', 2010, '978-84-96031-', 'En un futuro donde la realidad y los sueños se confunden, los personajes buscan respuestas en un mundo distópico y peligroso', '2025-04-11 01:01:00', '2025-04-11 01:01:00'),
(14, 'Eragon', 'Christopher Paolini', 2002, '978-0-375-826', 'Un joven granjero descubre que es el último de los jinetes de dragón, y debe unirse a la resistencia para derrotar a un imperio tiránico.', '2025-04-11 01:02:06', '2025-04-11 01:02:06'),
(15, 'La niebla', 'Stephen King', 1980, '978-0-7432-79', 'Un grupo de personas se queda atrapado en un supermercado, mientras extrañas criaturas surgen de la niebla.', '2025-04-11 01:03:06', '2025-04-11 01:03:06'),
(16, 'Un plano de piedad', 'María del Carmen Pérez', 2005, '978-0-7868-67', 'Una sociedad donde los habitantes viven bajo una opresión tecnológica, y uno de ellos desafía el sistema para encontrar la verdad.', '2025-04-11 01:31:15', '2025-04-11 01:31:15'),
(17, 'La chica del tren', 'Paula Hawkins', 2015, '978-1-250-081', 'Una mujer se ve envuelta en la desaparición de una persona, mientras su percepción de la realidad se ve afectada por sus propios traumas.', '2025-04-11 01:32:01', '2025-04-11 01:32:01'),
(18, 'El señor de los anillos: La comunidad del anillo', 'J.R.R. Tolkien', 1954, '978-0-618-129', 'Un hobbit y sus compañeros deben destruir un anillo de poder que podría destruir todo el mundo en una épica aventura', '2025-04-11 01:35:43', '2025-04-11 01:35:43');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `isbn` (`isbn`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
