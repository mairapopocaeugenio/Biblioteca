<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo isset($book) ? 'Editar Libro' : 'Agregar Libro'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootswatch@5.3.3/dist/sketchy/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h1><?php echo isset($book) ? 'Editar Libro' : 'Agregar Libro'; ?></h1>
        <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
        <form action="" method="POST">
            <fieldset>
            <div class="form-group">
                <label for="title">Título:</label>
                <input type="text" name="title" class="form-control" value="<?php echo isset($book) ? htmlspecialchars($book['title']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label for="author">Autor:</label>
                <input type="text" name="author" class="form-control" value="<?php echo isset($book) ? htmlspecialchars($book['author']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label for="published_year">Año de Publicación:</label>
                <input type="number" name="published_year" class="form-control" value="<?php echo isset($book) ? htmlspecialchars($book['published_year']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label for="isbn">ISBN:</label>
                <input type="text" name="isbn" class="form-control" value="<?php echo isset($book) ? htmlspecialchars($book['isbn']) : ''; ?>" required>
            </div>
            <div class="form-group">
                <label for="description">Descripción:</label>
                <textarea name="description" class="form-control"><?php echo isset($book) ? htmlspecialchars($book['description']) : ''; ?></textarea>
            </div>
            <button type="submit" class="btn btn-success"><?php echo isset($book) ? 'Actualizar' : 'Agregar'; ?></button>
            <a href="index.php" class="btn btn-danger">Cancelar</a>
        </form>
    </div>
</fieldset>
</body>
</html>