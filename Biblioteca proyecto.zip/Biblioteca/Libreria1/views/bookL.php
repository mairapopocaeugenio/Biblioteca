<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Libros</title>
    <link href="../Estilos/Style.css" rel="stylesheet" type="text/css"/>
<link href="https://cdn.jsdelivr.net/npm/bootswatch@5.3.3/dist/sketchy/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h1>Listado de Libros</h1>
        <hr>
        <a href="index.php?action=create" class="btn btn-primary">Añadir Libro</a>
        <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
        <fieldset>
        <table border="1" class="table">
            <thead>
                <tr>
                    <th>Título</th>
                    <th>Autor</th>
                    <th>Año de Publicación</th>
                    <th>ISBN</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($books as $book): ?>
                <tr>
                    <td><?php echo htmlspecialchars($book['title']); ?></td>
                    <td><?php echo htmlspecialchars($book['author']); ?></td>
                    <td><?php echo $book['published_year']; ?></td>
                    <td><?php echo htmlspecialchars($book['isbn']); ?></td>
                    <td>
                        <a href="index.php?action=edit&id=<?php echo $book['id']; ?>" class="btn btn-warning">Editar</a>
                        <form action="index.php?action=delete&id=<?php echo $book['id']; ?>" method="post" style="display:inline;">
                            <button type="submit" class="btn btn-danger" onclick="return confirm('¿Vas a eliminar este libro? Confirma tu decisión.');">Eliminar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        </fieldset>
        <div>
            <?php 
            for ($i = 1; $i <= ceil($totalBooks / 10); $i++): ?>
                <a class="btn btn-secondary" href="index.php?page=<?php echo $i; ?>"><?php echo $i; ?></a>
            <?php endfor; ?>
        </div>
    </div>
</body>
</html>
