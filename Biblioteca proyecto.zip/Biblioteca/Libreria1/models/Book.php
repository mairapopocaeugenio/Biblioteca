<?php
class Book {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function getAll($page, $limit) {
        $offset = ($page - 1) * $limit;
        $stmt = $this->db->prepare("SELECT * FROM books LIMIT :limit OFFSET :offset");
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function get($id) {
        $stmt = $this->db->prepare("SELECT * FROM books WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function create($title, $author, $published_year, $isbn, $description) {
        $stmt = $this->db->prepare("INSERT INTO books (title, author, published_year, isbn, description) VALUES (?, ?, ?, ?, ?)");
        return $stmt->execute([$title, $author, $published_year, $isbn, $description]);
    }

    public function update($id, $title, $author, $published_year, $isbn, $description) {
        $stmt = $this->db->prepare("UPDATE books SET title = ?, author = ?, published_year = ?, isbn = ?, description = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
        return $stmt->execute([$title, $author, $published_year, $isbn, $description, $id]);
    }

    public function delete($id) {
        $stmt = $this->db->prepare("DELETE FROM books WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public function count() {
        $stmt = $this->db->query("SELECT COUNT(*) FROM books");
        return $stmt->fetchColumn();
    }
}

