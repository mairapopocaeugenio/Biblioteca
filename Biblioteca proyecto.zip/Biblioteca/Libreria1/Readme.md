
Configuración del Entorno de Desarrollo
Para el desarrollo de este sistema, se utilizaron las siguientes herramientas:
Apache NetBeans: Como IDE principal para la codificación en PHP.
XAMPP: Para el servidor local, que incluye:
phpMyAdmin: Herramienta de gestión de bases de datos.
SQL: Para la creación y gestión de la base de datos a través de phpMyAdmin.

Configuración de XAMPP
Instalación:
•	Descarga e instala XAMPP desde [https://www.apachefriends.org/](https://www.apachefriends.org/).
•	Asegúrate de que los servicios de *Apache* y *MySQL* estén activos en el panel de control de XAMPP.

phpMyAdmin:
•	Accede a phpMyAdmin desde http://localhost/phpmyadmin.
•	Crea una nueva base de datos llamada biblioteca.

Carpeta del Proyecto:
•	Coloca la carpeta del proyecto (/libreria1/) dentro del directorio htdocs de XAMPP.
•	Accede al proyecto desde http://localhost/libreria1/.

Configuración de Apache NetBeans
Nuevo Proyecto:
•	Abre Apache NetBeans y selecciona File > New Project.
•	Elige PHP Application y configura la ruta del proyecto.

Servidor Local:
•	En Run Configuration, selecciona XAMPP como servidor local.
•	Configura la URL del proyecto como http://localhost/libreria1/.index.php

Base de Datos:
Configura la conexión con los siguientes datos:
   Host: localhost
   Usuario: root
   Contraseña: (deja vacío si no configuraste una)
   Base de datos: biblioteca

Creación de la Base de Datos
Ejecuta el siguiente script SQL en phpMyAdmin para crear la tabla books:
sql
CREATE DATABASE biblioteca;
USE biblioteca;

CREATE TABLE books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    published_year INT NOT NULL CHECK (published_year <= 2025),
    isbn VARCHAR(13) NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);


Herramientas Utilizadas
Apache NetBeans: IDE para la codificación.
XAMPP: Servidor local con Apache, MySQL y phpMyAdmin.
phpMyAdmin: Para la gestión de la base de datos.
Estructura del Proyecto
•	config/: Configuración de la base de datos.
•	controllers/: Controladores para la lógica de negocio.
•	models/: Modelos para interactuar con la base de datos.
•	views/: Vistas para la interfaz de usuario.

Accede al sistema desde `http://localhost/biblioteca/`.


Clase Database 
<?php
/**
 * Clase para manejar la conexión a la base de datos
 * 
 * Implementa el patrón Singleton para tener una única instancia de conexión
 */
class Database {
    /**
     * @var string $host Nombre del servidor de base de datos
     */
    private $host = 'localhost';
    /**
     * @var string $db_name Nombre de la base de datos
     */
    private $db_name = 'biblioteca';
    /**
     * @var string $username Usuario de la base de datos
     */
    private $username = 'root';
    /**
     * @var string $password Contraseña de la base de datos
     */
    private $password = '';
    /**
     * @var PDO|null $conn Instancia de conexión PDO
     */
    private $conn;

    /**
     * Establece la conexión a la base de datos
     * 
     * @return PDO Objeto de conexión PDO
     * @throws PDOException Si ocurre un error al conectar
     */
    public function connect() {
        $this->conn = null;
        try {
            $this->conn = new PDO(
                'mysql:host=' . $this->host . ';dbname=' . $this->db_name,
                $this->username, 
                $this->password
            );
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $e) {
            echo 'Connection Error: ' . $e->getMessage();
        }
        return $this->conn;
    }
}








Clase Book (Modelo)
<?php
/**
 * Modelo para la gestión de libros en la base de datos
 * 
 * Proporciona métodos CRUD para la tabla 'books'
 */
class Book {
    /**
     * @var PDO $conn Conexión a la base de datos
     */
    private $conn;
    /**
     * @var string $table Nombre de la tabla en la base de datos
     */
    private $table = 'books';
    /**
     * @var int $id ID del libro
     */
    public $id;
    /**
     * @var string $title Título del libro
     */
    public $title;
    /**
     * @var string $author Autor del libro
     */
    public $author;
    
    /**
     * @var int $published_year Año de publicación
     */
    public $published_year;
    /**
     * @var string $isbn Número ISBN del libro
     */
    public $isbn;
    /**
     * @var string|null $description Descripción del libro
     */
    public $description;

    /**
     * Constructor de la clase
     * 
     * @param PDO $db Instancia de conexión a la base de datos
     */
    public function __construct($db) {
        $this->conn = $db;
    }

    /**
     * Obtiene todos los libros con paginación
     * 
     * @param int $page Número de página (por defecto 1)
     * @param int $per_page Elementos por página (por defecto 10)
     * @return PDOStatement Resultado de la consulta
     */
    public function read($page = 1, $per_page = 10) {
        // ... método existente ...
    }

    /**
     * Cuenta el total de libros en la base de datos
     * 
     * @return int Total de libros
     */
    public function count() {
        // ... método existente ...
    }

    /**
     * Crea un nuevo libro en la base de datos
     * 
     * @return bool True si se creó correctamente, false en caso contrario
     */
    public function create() {
        // ... método existente ...
    }

    /**
     * Obtiene un libro específico por su ID
     * 
     * @return void Los datos del libro se asignan a las propiedades del objeto
     */
    public function readOne() {
        // ... método existente ...
    }

    /**
     * Actualiza un libro existente
     * 
     * @return bool True si se actualizó correctamente, false en caso contrario
     */
    public function update() {
        // ... método existente ...
    }

    /**
     * Elimina un libro de la base de datos
     * 
     * @return bool True si se eliminó correctamente, false en caso contrario
     */
    public function delete() {
        // ... método existente ...
    }
    /**
     * Busca libros por título, autor o ISBN
     * 
     * @param string $keyword Término de búsqueda
     * @return PDOStatement Resultado de la consulta
     */
    public function search($keyword) {
        // ... método existente ...
    }
}
Clase BookController
<?php
/**
 * Controlador para gestionar las operaciones CRUD de libros
 * 
 * Maneja las solicitudes HTTP y coordina las interacciones entre
 * la vista y el modelo
 */
class BookController {
    /**
     * @var Book $bookModel Instancia del modelo Book
     */
    private $bookModel;
    /**
     * @var PDO $db Conexión a la base de datos
     */
    private $db;
    /**
     * Constructor de la clase
     * 
     * Inicializa la conexión a la base de datos y el modelo Book
     */
    public function __construct() {
        $database = new Database();
        $this->db = $database->connect();
        $this->bookModel = new Book($this->db);
    }

    /**
     * Muestra la lista de libros con paginación
     * 
     * @param int $page Número de página (por defecto 1)
     * @return void Renderiza la vista index.php
     */
    public function index($page = 1) {
        // ... método existente ...
    }
    /**
     * Muestra el formulario para crear un nuevo libro y procesa el envío
     * 
     * @return void Renderiza la vista create.php
     */
    public function create() {
        // ... método existente ...
    }
    /**
     * Muestra el formulario para editar un libro y procesa el envío
     * 
     * @param int $id ID del libro a editar
     * @return void Renderiza la vista edit.php
     */
    public function edit($id) {
        // ... método existente ...
    }
    /**
     * Elimina un libro de la base de datos
     * 
     * @param int $id ID del libro a eliminar
     * @return void Redirige a la lista de libros
     */
    public function delete($id) {
        // ... método existente ...
    }
    /**
     * Busca libros por título, autor o ISBN
     * 
     * @return void Renderiza la vista index.php con los resultados
     */
    public function search() {
        // ... método existente ...
    }
    /**
     * Valida los datos del formulario de libro
     * 
     * @param array $data Datos del formulario ($_POST)
     * @return array Array de mensajes de error (vacío si no hay errores)
     */
    private function validate($data) {
        // ... método existente ...
    }
}
?>
```




Views
views/books/index.php
<?php
/**
 * Vista para mostrar la lista de libros
 * 
 * @var PDOStatement $books Resultado de la consulta de libros
 * @var int $page Número de página actual
 * @var int $total_pages Total de páginas disponibles
 */
?>
views/books/create.php
```php
<?php
/**
 * Vista para el formulario de creación de libros
 * 
 * @var array $errors Array de mensajes de error (opcional)
 */

views/books/edit.php
<?php
/**
 * Vista para el formulario de edición de libros
 * 
 * @var array $errors Array de mensajes de error (opcional)
 * @var Book $bookModel Instancia del modelo con los datos del libro
 */
```
