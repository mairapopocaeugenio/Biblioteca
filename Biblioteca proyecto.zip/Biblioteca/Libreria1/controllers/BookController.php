<?php
require_once 'config/db.php';
require_once 'models/Book.php';

class BookController {
    private $bookModel;

    public function __construct($db) {
        $this->bookModel = new Book($db);
    }

    public function listBooks() {
        $currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $limit = 10; // Libros por página
        $books = $this->bookModel->getAll($currentPage, $limit);
        $totalBooks = $this->bookModel->count();
        include 'views/bookL.php';
    }

    public function createBook() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Validaciones
            if (empty($_POST['title']) || empty($_POST['author']) || empty($_POST['published_year']) || empty($_POST['isbn'])) {
                $error = "Todos los campos son obligatorios.";
            } elseif (!preg_match('/^\d{3}-\d{1,5}-\d{1,7}-\d{1,7}-\d{1}$/', $_POST['isbn'])) {
                $error = "El ISBN no tiene un formato válido.";
            } elseif ($_POST['published_year'] > date("Y")) {
                $error = "El año de publicación no puede ser mayor al año actual.";
            } else {
                // Crear libro
                $this->bookModel->create($_POST['title'], $_POST['author'], $_POST['published_year'], $_POST['isbn'], $_POST['description']);
                header('Location: index.php');
                exit();
            }
        }
        include 'views/bookF.php';
    }
public function editBook($id) {
    $book = $this->bookModel->get($id);
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Validaciones
        if (empty($_POST['title']) || empty($_POST['author']) || empty($_POST['published_year']) || empty($_POST['isbn'])) {
            $error = "Todos los campos son obligatorios.";
        } elseif (!preg_match('/^(97(8|9))?\d{9}(\d|X)$/', str_replace('-', '', $_POST['isbn']))) {
            $error = "El ISBN no tiene un formato válido.";
        } elseif ($_POST['published_year'] > date("Y")) {
            $error = "El año de publicación no puede ser mayor al año actual";
        } else {
            // Actualizar libro
            $this->bookModel->update($id, $_POST['title'], $_POST['author'], $_POST['published_year'], $_POST['isbn'], $_POST['description']);
            header('Location: index.php');
            exit();
        }
    }
    include 'views/bookF.php';
}

    public function deleteBook($id) {
        $this->bookModel->delete($id);
        header('Location: index.php');
        exit();
    }
}
