<?php
require_once 'controllers/BookController.php';

$controller = new BookController($pdo);
$action = isset($_GET['action']) ? $_GET['action'] : 'list';

if ($action === 'create') {
    $controller->createBook();
} elseif ($action === 'edit') {
    $id = $_GET['id'] ?? null;
    if ($id) {
        $controller->editBook($id);
    } else {
        header('Location: index.php');
        exit();
    }
} elseif ($action === 'delete') {
    $id = $_GET['id'] ?? null;
    if ($id) {
        $controller->deleteBook($id);
    } else {
        header('Location: index.php');
        exit();
    }
} else {
    $controller->listBooks();
}
